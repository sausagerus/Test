declare let systemDictionary: Record<string, Record<string, string>>;
